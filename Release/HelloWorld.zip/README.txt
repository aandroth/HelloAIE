1. Open HelloWorld.exe
2. Read the text
3. Profit

Credits
_______


Programmer,
Aaron Andrews - aaron.andrews@students.aie.edu.au